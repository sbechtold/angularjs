var config = {
  classDB : {
//    user: 'classUser',
//    pass: 'classUser',
    url: 'mongodb://127.0.0.1:27017/class'
  },
  localhost: {
    url: 'http://localhost:8080'
  }
};

module.exports = config;

